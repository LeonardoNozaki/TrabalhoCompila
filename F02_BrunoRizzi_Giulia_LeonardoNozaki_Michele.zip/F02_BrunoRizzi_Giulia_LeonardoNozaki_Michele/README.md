# Compiladores

**Universidade Federal de São Carlos - UFSCar Sorocaba**

Este trabalho prático foi desenvolvido para a disciplina de Compiladores, ministrada pela professora Leticia Berto.

#### Integrantes: 

[Bruno Rizzi](https://github.com/BrunoRizzi/)

Giulia Fazzi

[Leonardo Nozaki](https://github.com/LeonardoNozaki/)

[Michele Carvalho](https://github.com/xmixele/)

#### Fase 1:
O objetivo da primeira fase é implementar os analisadores léxicos e sintáticos do compilador. Linguagem adotada: Java.

#### Executando:
Para compilar:
> make

Para executar:
> java Main arquivo_entrada arquivo_saida

Remover *.class*:
> make clean
